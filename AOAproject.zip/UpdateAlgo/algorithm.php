<?php
include_once "database.php";
/*$sql ="INSERT INTO rating(name,rating) VALUES ('Broadway',1)";
if($stmt=mysqli_prepare($link,$sql))
{
	mysqli_stmt_execute($stmt);
	echo "Data inserted";
}
else
echo "Connection error";*/

$sql = "SELECT * FROM rating";
$result = mysqli_query($link,$sql);
$data=array();
if(mysqli_num_rows($result)>0)
{
	while($row=mysqli_fetch_assoc($result))
	{
		$data[]=$row;
	}
}
//print_r($data);
$arr1=array();
$arr2=array();
$count=0;
foreach ($data as $rating)
{
	$arr1[$count]= $rating['name'];
	$arr2[$count]= $rating['rating'];
	$count++;
}

$review=array();
for ($i=0;$i<$count;$i++)
{ 
	$review[$arr1[$i]]=$arr2[$i];
}

echo "\n";
$sorted_array = array();
my_sort($review, $sorted_array);
foreach($sorted_array as $x)
{
	echo $x;
	echo "<br>";
}
function my_sort(&$aArray, &$sorted_array) {
	$bArray = $aArray;
	foreach ($aArray as $key1 => $value1) {
	  //echo $key1,$value1, "\n";
	  $max_value = null;
	  $max_key = null;
	  foreach($bArray as $key2 => $value2) {
	   
		if (null === $max_value || $value2 > $max_value) {
		  $max_key = $key2;
		  $max_value = $value2;
		 
		}
	  }
	  
	  $sorted_array[$max_key] = $max_value;
	  if (($key = array_search($max_value, $bArray)) !== false) {
		unset($bArray[$key]);
	  }
	}
}
  
?>