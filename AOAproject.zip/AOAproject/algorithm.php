<?php

function my_sort(&$aArray, &$sorted_array) {
  $bArray = $aArray;
  foreach ($aArray as $key1 => $value1) {
	//echo $key1,$value1, "\n";
	$max_value = null;
	$max_key = null;
	foreach($bArray as $key2 => $value2) {

	  if (null === $max_value || $value2 > $max_value) {
		$max_key = $key2;
		$max_value = $value2;

	  }
	}

	$sorted_array[$max_key] = $max_value;
	if (($key = array_search($max_value, $bArray)) !== false) {
	  unset($bArray[$key]);
	}
  }
}

?>