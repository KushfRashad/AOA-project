<?php
include_once "database.php";

/*$sql ="INSERT INTO rating(name,rating) VALUES ('Broadway',1)";
if($stmt=mysqli_prepare($link,$sql))
{
	mysqli_stmt_execute($stmt);
	echo "Data inserted";
}
else 
echo "Connection error";*/


$sql = "SELECT * FROM rating";


$result = mysqli_query($link,$sql);
$data=array();
if(mysqli_num_rows($result)>0)
{
	while($row=mysqli_fetch_assoc($result))
	{
		$data[]=$row;
	}

}
//print_r($data);
$arr1=[];
$arr2=[];
$count=0;
foreach ($data as $rating) 
{

	$arr1[$count]= $rating['name'];
	$arr2[$count]= $rating['rating'];
	$count++;
}
for ($i=0;$i<=$count;$i++)
{
	echo ($arr1[$i]." ".$arr2[$i]);
	echo "<br>";
}
?>


