<?php

$ch=curl_init();

$url="https://www.tripadvisor.com/Restaurants-g295413-Lahore_Punjab_Province.html";
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);    //IF IT FALSE THEN IT WILL DISPLAY url as it is but we don't want so take it true

$result=curl_exec($ch) ;  //set the options of curl and execute curl
curl_close($ch);
$DOM =new DOMDocument;
libxml_use_internal_errors(true);
$DOM->loadHTML($result);

$elements= $DOM->getElementsByTagName('a');
for ($i=0;$i<$elements->length;$i++)
{
	if(preg_match('/#REVIEWS+/', $elements->item($i)->getAttribute('href'),$match))
	{
		//echo $elements->item($i)->nodeValue."<br>";
		echo $elements->item($i)->getAttribute('href')."<br>";
	}
	//echo $elements->item($i)->getAttribute('href')."<br>";
	/*if(preg_match('/d{1,}/',$elements->item($i)->nodeValue,$match))
	{
		echo $elements->item($i)->nodeValue."<br>";
	}*/
}


?>