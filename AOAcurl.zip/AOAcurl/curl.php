<?php

$ch=curl_init();

$url = "https://www.tripadvisor.com/RestaurantsNear-g295413-d947765-Pizza_Hut-Lahore_Punjab_Province.html";
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);    //IF IT FALSE THEN IT WILL DISPLAY url as it is but we don't want so take it true

$result=curl_exec($ch) ;  //set the options of curl and execute curl
curl_close($ch);

print_r($result);

?>