<!doctype html>
<html lang="en">
  <head>
    <title>Suggestions</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
    .div1{
    height:100%;
    width:100%;
    justify-content:center;
    background-color: #ccccff;
    /*background-image:url("./images/pic8.jpg");*/
    background-repeat:no-repeat;
    background-size:100%;
    align-items: center;
    display:flex;
    flex-direction:column;
    }
    .div2{
    width:fit-content;
    height:fit-content;
    display: table;
    justify-content:center;
    flex-direction:column;
    padding: 15px 30px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0px 10px 50px #555;
    background-color: white;
    border:4px #6666ff solid;
    }
    .label1{
        font-family:Georgia, 'Times New Roman', Times, serif;
        font-size:x-large;
        font-weight: bold;
    }
    table {
      border-collapse: collapse;
      width: 50%;
      color: darkblue;
      font-family: monospace;
      font-size: 10px;
      text-align: left;
    }
    th {
      background-color: #3366ff;
      color: white;
    }
    tr:nth-child(even) {background-color: #b3c6ff}

      #table
      {
        font-family: "Times New Roman", Times, serif;
        width:500px;
        line-height: 30px;
        align: center;
        border:4px;
      }
      .button1{
        font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        font-size:x-large;
        display: inline-block;
        text-align: center;
    }
    .a1{
      color:black;
    }

    </style>
</head>
  <body>
      <div class="div1">
          <div class="div2">
            <label class="label1">List of Restaurants</label>
      <table id="table">
        <tr>
          <th>#</th>
          <th>Restaurants</th>
          <th>Rating</th>
        </tr>
        <?php
        require "database.php";
        $area = $_POST["dropArea"];
        $conn = mysqli_connect("localhost", "root", "", "restaurantData");
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        if($area == 'DHA')
        {
          $sql1 = "SELECT name,rate From newDefence";
        }
        else if($area == 'MM Alam Road')
        {
          $sql1 = "SELECT name,rate From newMM";
        }
        else if($area == 'Mall Road')
        {
          $sql1 = "SELECT name,rate From newMall";
        }
        else
        {
          $sql1 = "SELECT name,rate From newGul";
        }

        $result = $conn->query($sql1);
        $i=0;
        while($rows=mysqli_fetch_assoc($result))
        {
            $i++;
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['rate'];?></td>


            </tr>
            <?php
        }
        ?>

      </table>
      <button class="button1"><a class="a1" href="Search.php">Back</a></button>
      </div>
      </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>